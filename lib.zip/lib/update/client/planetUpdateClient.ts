"use client";

import * as MainPageType from "@/lib/mainPageTypes";

import * as SelectedPlanet from "@/lib/localStorage/selectedPlanet";
import * as PlanetProgress from "@/lib/gameplay/planetProgress";
import * as ClientUpdate from "@/lib/update/client/clientUpdate";
import { PlanetRow } from "@/lib/db/dbTypes";

export function updatePlanetPredictedData(cdsrController: MainPageType.CDSRController): void
{
	const playerState: MainPageType.PlayerState = cdsrController[0].psController[0];
	const selectedPlanet: PlanetRow = SelectedPlanet.getSelectedPlanet(playerState);

	const now: number = Date.now();
	const advancedPlanetRow: PlanetRow = PlanetProgress.applyPlanetProgress(selectedPlanet, cdsrController[0].sdsController[0], now, true);

	// applyPlanetProgress returns the same reference when nothing changed
	// (elapsed <= 0). Return prev unchanged so React skips the update.
	if (advancedPlanetRow === selectedPlanet)
	{
		return;
	}
	const updatedPlanetRows: PlanetRow[] = ClientUpdate.replacePlanetRowInArrayByUpdatedPlanetRow(playerState.predictedDBData.planetRows, advancedPlanetRow);

	const updatedPlayerState: MainPageType.PlayerState =
	{
		...playerState,
		predictedDBData:
		{
			...playerState.predictedDBData,
			planetRows: updatedPlanetRows,
		},
	};
	
	cdsrController[0].psController[1](updatedPlayerState);
}