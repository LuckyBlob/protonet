"use client";

import * as MainPageType from "@/lib/mainPageTypes";
import * as PlanetUpdateClient from "@/lib/update/client/planetUpdateClient";
import * as DBType from "@/lib/db/dbTypes";

export function replacePlanetRowInArrayByUpdatedPlanetRow(planetRows: DBType.PlanetRow[], updatedPlanetRow: DBType.PlanetRow): DBType.PlanetRow[]
{
	const newPlanetRows: DBType.PlanetRow[] = planetRows.map((planetRow: DBType.PlanetRow): DBType.PlanetRow =>
	{
		if (planetRow.id === updatedPlanetRow.id)
		{
			return updatedPlanetRow;
		}

		return planetRow;
	});

	return newPlanetRows;
}

export function runClientTick(cdsrController: MainPageType.CDSRController): void
{
	PlanetUpdateClient.updatePlanetPredictedData(cdsrController);
}