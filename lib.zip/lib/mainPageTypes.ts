import * as ServerDataTypes from "@/lib/serverData/serverDataTypes";
import * as UseLoadClientDataState from "@/lib/use/useLoadClientDataState";
import * as UseLoadCurrentUser from "@/lib/use/useLoadCurrentUser";
import { PlayerRow, PlanetRow } from "@/lib/db/dbTypes";

export type PlayerData =
{
	playerRow: PlayerRow;
	planetRows: PlanetRow[];
};

export type PlayerState =
{
	loaded: boolean;
	dbData: PlayerData;
	predictedDBData: PlayerData;
	selectedPlanetId: number;
	lastFetchTimestamp: number;
};

export type PSController  = [PlayerState, (value: PlayerState | ((prev: PlayerState) => PlayerState)) => void];
export type SDSController  = [ServerDataTypes.ServerData, (value: ServerDataTypes.ServerData) => void];
export type CDSRController  = [UseLoadClientDataState.ClientDataStateResult, (value: UseLoadClientDataState.ClientDataStateResult) => void];
export type CUController  = [UseLoadCurrentUser.CurrentUserResult, (value: UseLoadCurrentUser.CurrentUserResult) => void];
export type CVController  = [string, (value: string) => void];