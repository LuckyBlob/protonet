"use client";

import { useEffect, useState } from "react";
import * as PlayerUpdateClient from "@/lib/update/client/playerUpdateClient";
import * as MainPageType from "@/lib/mainPageTypes";

export type ClientDataStateResult =
{
	psController: MainPageType.PSController;
	sdsController: MainPageType.SDSController;
	isLoading: boolean;
};

const UnloadedUseClientDataStateResult =
{
	psController: {} as MainPageType.PSController,
	sdsController: {} as MainPageType.SDSController,
	isLoading: true
};

export function useLoadClientDataState(enabled: boolean): MainPageType.CDSRController
{
	const cdsrController: MainPageType.CDSRController = useState<ClientDataStateResult>(UnloadedUseClientDataStateResult);

	useEffect(() =>
	{
		if (enabled === false)
		{
			return;
		}

		const loadClientDataState: () => Promise<void> = async () =>
		{
			await PlayerUpdateClient.fetchAndSetPlayerState(cdsrController[0].psController);
			await PlayerUpdateClient.fetchAndSetServerData(cdsrController[0].sdsController);
			const loadedClientDataStateResult: ClientDataStateResult =
			{
				...cdsrController[0],
				isLoading: false,
			};
			cdsrController[1](loadedClientDataStateResult);
		};

		loadClientDataState();
	}, [enabled]);

	return cdsrController;
}