"use client";

import { useEffect, useState } from "react";
import * as MainPageType from "@/lib/mainPageTypes";
import * as ClientUpdate from "@/lib/update/client/clientUpdate";

const tickIntervalMilliseconds: number = 1000;

export function useAnimationTimer(cdsrController: MainPageType.CDSRController): void
{
	const tickCounterState: [number, (value: number | ((prev: number) => number)) => void] = useState<number>(0);
	const setTickCounter: (value: number | ((prev: number) => number)) => void = tickCounterState[1];

	useEffect(() =>
	{
		if (cdsrController[0].isLoading)
		{
			return;
		}

		const intervalId: NodeJS.Timeout = setInterval(() =>
		{
			setTickCounter((prev: number): number =>
			{
				return prev + 1;
			});

			ClientUpdate.runClientTick(cdsrController);
		}, tickIntervalMilliseconds);

		const cleanup: () => void = (): void =>
		{
			clearInterval(intervalId);
		};

		return cleanup;
	}, [cdsrController[0].isLoading]);
}