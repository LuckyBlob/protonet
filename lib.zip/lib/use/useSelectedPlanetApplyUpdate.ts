"use client";

import { useEffect } from "react";
import * as MainPageType from "@/lib/mainPageTypes";
import * as PlanetUpdateClient from "@/lib/update/client/planetUpdateClient";

export function useSelectedPlanetApplyUpdate(cdsrController: MainPageType.CDSRController): void
{
	const playerState: MainPageType.PlayerState = cdsrController[0].psController[0];

	useEffect(() =>
	{
        // This will fire once at the begining of the render, so we need to gate.
        if (playerState.loaded === false)
        {
            return;
        }
        
        PlanetUpdateClient.updatePlanetPredictedData(cdsrController);
	}, [playerState.selectedPlanetId]);
}