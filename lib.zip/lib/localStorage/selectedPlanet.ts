import { PlanetRow } from "@/lib/db/dbTypes";
import * as MainPageType from "@/lib/mainPageTypes";

const SELECTED_PLANET_STORAGE_KEY: string = "protonet.selectedPlanetId";

export function readStoredSelectedPlanetId(): number | null
{
	if (typeof window === "undefined")
	{
		return null;
	}

	const rawValue: string | null = window.localStorage.getItem(SELECTED_PLANET_STORAGE_KEY);

	if (rawValue === null)
	{
		return null;
	}

	const parsedValue: number = Number.parseInt(rawValue, 10);

	if (Number.isNaN(parsedValue) === true)
	{
		return null;
	}

	return parsedValue;
}

function writeStoredSelectedPlanetId(planetId: number): void
{
	if (typeof window === "undefined")
	{
		return;
	}

	window.localStorage.setItem(SELECTED_PLANET_STORAGE_KEY, String(planetId));
}

export function resolveSelectedPlanetId(planetRows: PlanetRow[], candidateId: number | null): number | null
{
	if (planetRows.length === 0)
	{
		return null;
	}

	if (candidateId !== null)
	{
		const matchingPlanet: PlanetRow | undefined = planetRows.find((planetRow: PlanetRow) =>
		{
			return planetRow.id === candidateId;
		});

		if (matchingPlanet !== undefined)
		{
			return matchingPlanet.id;
		}
	}

	const firstPlanet: PlanetRow = planetRows[0];

	return firstPlanet.id;
}

export function getSelectedPlanet(playerState: MainPageType.PlayerState): PlanetRow
{
	const planetRows: PlanetRow[] = playerState.predictedDBData.planetRows;

	const matchingPlanet: PlanetRow | undefined = planetRows.find((planetRow: PlanetRow) =>
	{
		return planetRow.id === playerState.selectedPlanetId;
	});

	if (matchingPlanet !== undefined)
	{
		return matchingPlanet;
	}

	return planetRows[0];
}

export function setSelectedPlanetInPlayerState(psController: MainPageType.PSController, requestedPlanetId: number): void
{
    const prevPlayerState: MainPageType.PlayerState = psController[0];

    if (prevPlayerState.loaded === false)
    {
        return;
    }

    const planetRows: PlanetRow[] = prevPlayerState.predictedDBData.planetRows;
    const resolvedId: number | null = resolveSelectedPlanetId(planetRows, requestedPlanetId);

    if (resolvedId === null)
    {
        return;
    }

    if (resolvedId === prevPlayerState.selectedPlanetId)
    {
        return;
    }

    writeStoredSelectedPlanetId(resolvedId);

    const updatedPlayerState: MainPageType.PlayerState =
    {
        ...prevPlayerState,
        selectedPlanetId: resolvedId,
    };

	psController[1](updatedPlayerState);
}