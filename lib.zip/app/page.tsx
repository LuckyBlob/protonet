"use client";

import { useRouter } from "next/navigation";
import { GameLayoutElement} from "@/components/mainPageElements/gameLayoutElement";
import { SideBarElement} from "@/components/mainPageElements/sideBarElement";
import { TopBarElement} from "@/components/mainPageElements/topBarElement";
import { MainWindowElement} from "@/components/mainPageElements/mainWindowElement";
import { LoadingElement } from "@/components/mainPageElements/loadingElement";
import * as AuthClient from "@/lib/authentication/authClient";
import * as PlayerUpdateClient from "@/lib/update/client/playerUpdateClient";
import * as SelectedPlanetDisplay from "@/lib/update/client/selectedPlanetDisplay";
import { PlanetSelector } from "@/components/mainPageElements/planetSelector";

import * as UseLoadCurrentUser from "@/lib/use/useLoadCurrentUser";
import * as UseLoadClientDataState from "@/lib/use/useLoadClientDataState";
import * as UseAnimationTimer from "@/lib/use/useAnimationTimer";
import * as UseCurrentView from "@/lib/use/useCurrentView"
import * as UseSelectedPlanetApplyUpdate from "@/lib/use/useSelectedPlanetApplyUpdate"
import * as MainPageType from "@/lib/mainPageTypes";

export default function Home()
{
	const router = useRouter();
	const cuController: MainPageType.CUController = UseLoadCurrentUser.useLoadCurrentUser();
	const cdsrController: MainPageType.CDSRController = UseLoadClientDataState.useLoadClientDataState(cuController[0].user !== null);
	const cvController: MainPageType.CVController = UseCurrentView.useCurrentView();

	UseAnimationTimer.useAnimationTimer(cdsrController);
	UseSelectedPlanetApplyUpdate.useSelectedPlanetApplyUpdate(cdsrController);

	if (shouldShowLoading(cuController, cdsrController))
	{
		return <LoadingElement />;
	}
	const displayValues: SelectedPlanetDisplay.SelectedPlanetDisplayValues = SelectedPlanetDisplay.getSelectedPlanetDisplayValues(cdsrController);

	const pageComponent: React.ReactElement =
	(
		<GameLayoutElement
			sideBar={
				<SideBarElement
					cuController={cuController}
					cvController={cvController}
					cdsrController={cdsrController}
					router={router}
					onLogout={handleLogout}
					onRefreshServerData={handleRefreshServerData}
				/>
			}
			topBar={
				<TopBarElement
					cdsrController={cdsrController}
					planetSelector={
						<PlanetSelector cdsrController={cdsrController}/>
					}
				/>
			}
			mainWindow={
				<MainWindowElement
					cvController={cvController}
					cdsrController={cdsrController}
				/>
			}
		/>
	);

	return pageComponent;
}

function shouldShowLoading(cuController: MainPageType.CUController, cdsrController: MainPageType.CDSRController)
{
	if (cuController[0].isLoading || cdsrController[0].isLoading)
	{
		return true;
	}

	if (cuController[0].user === null)
	{
		return true;
	}

	return false;
}

async function handleLogout(router: ReturnType<typeof useRouter>): Promise<void>
{
	await AuthClient.tryLogout();
	router.push("/login");
};

async function handleRefreshServerData(cdsrController: MainPageType.CDSRController): Promise<void>
{
	await PlayerUpdateClient.tryRefreshServerData(cdsrController);
};

