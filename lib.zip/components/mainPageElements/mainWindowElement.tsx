import * as MainPageType from "@/lib/mainPageTypes";

import { GameView } from "@/components/views/gameView";
import { UpgradeView } from "@/components/views/upgradeView";
import { StatsView } from "@/components/views/statsView";

type MainWindowProps =
{
	cvController: MainPageType.CVController;
	cdsrController: MainPageType.CDSRController;
};

export function MainWindowElement(props: MainWindowProps): React.ReactElement
{
	if (props.cvController[0] === "game")
	{
		return <GameView cdsrController={props.cdsrController} />;
	}

	if (props.cvController[0] === "upgrades")
	{
		return <UpgradeView cdsrController={props.cdsrController} />;
	}

	if (props.cvController[0] === "stats")
	{
		return <StatsView cdsrController={props.cdsrController} />;
	}

	return <div>Unknown view</div>;
}
