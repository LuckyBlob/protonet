"use client";

import * as MainPageType from "@/lib/mainPageTypes";

type StatsViewProps =
{
	cdsrController: MainPageType.CDSRController;
};

export function StatsView(props: StatsViewProps): React.ReactElement
{
	const statsViewElement: React.ReactElement =
	(
		<div>You're the top player!</div>
	);

	return statsViewElement;
}