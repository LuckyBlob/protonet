"use client";

import * as MainPageType from "@/lib/mainPageTypes";

type GameViewProps =
{
	cdsrController: MainPageType.CDSRController;
};

export function GameView(props: GameViewProps): React.ReactElement
{
	const gameViewElement: React.ReactElement =
	(
		<div>
			Future cool image.
		</div>
	);

	return gameViewElement;
}