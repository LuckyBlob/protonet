import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import * as Auth from "@/lib/auth";
import { UserRow, SessionRow, PlanetRow } from "@/lib/dbTypes";

import { sessionCookieName, sessionDurationSeconds } from "@/lib/auth";
import * as PlanetServer from "@/lib/planetServer";
import * as Database from "better-sqlite3";
import { databaseConnection } from "@/lib/db";
import { PlayerRow } from "@/lib/dbTypes";

export async function POST(request: Request): Promise<NextResponse>
{
	const requestBody: { username: string; password: string } = await request.json();
	const username: string = requestBody.username;
	const password: string = requestBody.password;

	const user: UserRow | null = Auth.findUserByUsername(username);
	if (user === null)
	{
		return NextResponse.json(
			{ error: "Invalid username or password" },
			{ status: 401 }
		);
	}

	const passwordIsValid: boolean = await Auth.verifyPassword(password, user.password_hash);
	if (passwordIsValid === false)
	{
		return NextResponse.json(
			{ error: "Invalid username or password" },
			{ status: 401 }
		);
	}

	const session: SessionRow = Auth.createSession(user.id);

	const cookieStore = await cookies();
	cookieStore.set(sessionCookieName, session.token,
	{
		httpOnly: true,
		secure: true,
		sameSite: "lax",
		maxAge: sessionDurationSeconds,
		path: "/",
	});

	const playerRow: PlayerRow = databaseConnection.prepare("SELECT * FROM player WHERE user_id = ?").get(user.id) as PlayerRow;
	PlanetServer.assignStartingPlanets(playerRow);

	return NextResponse.json({ username: user.username });
}