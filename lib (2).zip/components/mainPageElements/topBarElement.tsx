import { formatRemainingTimeMs } from "@/lib/helper/timeFormat";
import * as MainPageType from "@/lib/mainPageTypes";
import * as DBType from "@/lib/db/dbTypes";
import * as Association from "@/lib/gameplay/associations";
import * as Production from "@/lib/gameplay/production";
import * as GameType from "@/lib/gameplay/gameTypes";
import * as UseLoadClientDataState from "@/lib/use/useLoadClientDataState";

type TopBarProps =
{
    clientDataStateResult: UseLoadClientDataState.ClientDataStateResult;
    planetSelector: React.ReactElement;
};

export function TopBarElement(props: TopBarProps): React.ReactElement
{
    const selectedPlanetRow: DBType.PlanetRow | undefined = props.clientDataStateResult.psController[0].predictedDBData.planetRows.find((planet: DBType.PlanetRow): boolean =>
    {
    	return planet.id === props.clientDataStateResult.psController[0].selectedPlanetId;
    });

    if (selectedPlanetRow === undefined)
    {
        return <div></div>
    }

    const isBuilding: boolean = selectedPlanetRow.building_upgrade_completes_at !== 0;
    const remainingMs: number = selectedPlanetRow.building_upgrade_completes_at - Date.now();
    const buildHintText: string = isBuilding === true ? ` (${formatRemainingTimeMs(remainingMs)})` : "";

    const topBarElement: React.ReactElement =
    (
        <div className="h-[70px] bg-black/50 text-white pt-5 px-4 flex justify-between items-start">
            <div className="flex items-center">
                {props.planetSelector}
            </div>
            <div className="flex gap-8">
                <div>🪨Iron: {Association.getRessourceQuantityForRessourceType(selectedPlanetRow, GameType.RESSOURCE_1)}</div>
                <div>⛏️ Iron Rate: {Production.getPlanetProductionRatePerSecond(selectedPlanetRow, GameType.RESSOURCE_1, props.clientDataStateResult.sdsController[0]) * 3600}/h{buildHintText}</div>
            </div>
        </div>
    );

    return topBarElement;
}
