import * as ServerDataType from "@/lib/serverData/serverDataTypes";
import * as PlayerDataType from "@/lib/playerData/playerDataTypes";
import * as UseLoadCurrentUser from "@/lib/use/useLoadCurrentUser";

export type PSController  = [PlayerDataType.PlayerState, (value: PlayerDataType.PlayerState | ((prev: PlayerDataType.PlayerState) => PlayerDataType.PlayerState)) => void];
export type SDSController  = [ServerDataType.ServerData, (value: ServerDataType.ServerData) => void];
export type CUController  = [UseLoadCurrentUser.CurrentUserResult, (value: UseLoadCurrentUser.CurrentUserResult) => void];
export type CVController  = [string, (value: string) => void];
export type LSController  = [PlayerDataType.LoadingState, (value: PlayerDataType.LoadingState) => void];