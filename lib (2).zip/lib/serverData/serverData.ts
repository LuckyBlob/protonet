import Database from "better-sqlite3";

import * as DB from "@/lib/db/db";
import * as DBTypes from "@/lib/db/dbTypes";

import * as ServerDataTypes from "@/lib/serverData/serverDataTypes";

let cachedServerData: ServerDataTypes.ServerData | null = null;

function loadServerConfigFromDatabase(): DBTypes.ServerConfigRow
{
	const selectStatement: Database.Statement = DB.databaseConnection.prepare(
		"SELECT * FROM server_config WHERE id = 1"
	);
	const serverConfigRow: DBTypes.ServerConfigRow | undefined = selectStatement.get() as DBTypes.ServerConfigRow | undefined;

	if (serverConfigRow === undefined)
	{
		throw new Error("server_config row is missing");
	}

	return serverConfigRow;
}

function loadServerStateFromDatabase(): ServerDataTypes.ServerData
{
	const serverConfigRow: DBTypes.ServerConfigRow = loadServerConfigFromDatabase();

	const serverData: ServerDataTypes.ServerData =
	{
		config: serverConfigRow,
	};
	return serverData;
}

export function getServerData(): ServerDataTypes.ServerData
{
	if (cachedServerData === null)
	{
		cachedServerData = loadServerStateFromDatabase();
	}
	return cachedServerData;
}

export function reloadServerData(): void
{
	cachedServerData = null;
}